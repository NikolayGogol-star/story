// LOCAL SIMULATOR ONLY. No Gmail requests, no production credentials, in-memory D1.
// Never deploy this file as a Worker. Use synthetic letter text and example.net email.
import {createServer} from 'node:http';
import {DatabaseSync} from 'node:sqlite';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {resolve,extname} from 'node:path';
import worker,{OPEN_AT} from './worker.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const db=new DatabaseSync(':memory:');db.exec(await readFile(new URL('./schema.sql',import.meta.url),'utf8'));
const DB={prepare(sql){let args=[];return {bind(...a){args=a;return this;},async first(){return db.prepare(sql).get(...args)||null;},async all(){return {results:db.prepare(sql).all(...args)};},async run(){return db.prepare(sql).run(...args);}};}};
const port=Number(process.env.CAPSULE_PREVIEW_PORT||8028),origin='http://127.0.0.1:'+port;
let now=Date.parse('2026-10-26T12:00:00Z'),failSave=false;
Date.now=()=>now;
const env={DB,ADMIN_TOKEN:'local-simulator-only-'.repeat(3),LETTER_KEY:Buffer.alloc(32,9).toString('base64'),RATE_SALT:'local-simulator',ALLOWED_ORIGIN:origin,TURNSTILE_HOSTNAME:'127.0.0.1',TURNSTILE_SECRET:'simulated',GMAIL_SENDER:'simulator@gmail.com',GOOGLE_CLIENT_ID:'simulated',GOOGLE_CLIENT_SECRET:'simulated',GOOGLE_REFRESH_TOKEN:'simulated'};
globalThis.fetch=async()=>Response.json({success:true,hostname:'127.0.0.1',action:'capsule'});
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css','.png':'image/png','.svg':'image/svg+xml','.woff2':'font/woff2','.mp3':'audio/mpeg'};
createServer(async(req,res)=>{
 try{
 const u=new URL(req.url,origin);
 if(u.pathname==='/__preview/open'){now=OPEN_AT;res.end('Simulated Moscow opening time');return;}
 if(u.pathname==='/__preview/fail'){failSave=true;res.end('Next save will fail');return;}
 if(u.pathname.startsWith('/api/')){
  if(failSave&&u.pathname==='/api/letters'){failSave=false;res.writeHead(503,{'Content-Type':'application/json'});res.end('{"code":"simulated_failure"}');return;}
  const chunks=[];for await(const c of req)chunks.push(c);
  const request=new Request(origin+u.pathname.slice(4),{method:req.method,headers:{...req.headers,origin,'cf-connecting-ip':'192.0.2.5'},body:req.method==='GET'?undefined:Buffer.concat(chunks)});
  const response=await worker.fetch(request,env);res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));return;
 }
 if(u.pathname==='/turnstile-simulator.js'){
  res.setHeader('Content-Type','text/javascript');res.end('window.turnstile={render(selector,options){document.querySelector(selector).textContent="Локальная проверка (эмулятор)";options.callback("simulator-token");window.simulatorCallback=options.callback;return 1;},reset(){window.simulatorCallback("simulator-token");}};');return;
 }
 const file=resolve(root,'.'+(u.pathname==='/'?'/index.html':decodeURIComponent(u.pathname)));
 if(!file.startsWith(root)||file.includes('/capsule-server/')){res.writeHead(403);res.end();return;}
 let value=await readFile(file);
 if(file.endsWith('/config.js'))value=Buffer.from(value.toString().replace('CAPSULE_ENABLED: false','CAPSULE_ENABLED: true').replace("CAPSULE_API_URL: ''",`CAPSULE_API_URL: '${origin}/api'`).replace("CAPSULE_TURNSTILE_SITEKEY: ''","CAPSULE_TURNSTILE_SITEKEY: 'simulator'"));
 if(file.endsWith('/capsule.js'))value=Buffer.from(value.toString().replace('https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit',origin+'/turnstile-simulator.js'));
 if(file.endsWith('/index.html'))value=Buffer.from(value.toString().replace('<body>','<body><p style="color:#f4e8d0;text-align:center">ЛОКАЛЬНЫЙ ЭМУЛЯТОР — почта не отправляется. Не вводите личные данные.</p>'));
 res.writeHead(200,{'Content-Type':types[extname(file)]||'application/octet-stream','Cache-Control':'no-store'});res.end(value);
 }catch{res.writeHead(404);res.end('Not found');}
}).listen(port,'127.0.0.1',()=>console.log('Local capsule simulator: '+origin));
