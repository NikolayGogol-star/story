CREATE TABLE IF NOT EXISTS letters (
 id TEXT PRIMARY KEY, token_hash TEXT NOT NULL UNIQUE, encrypted TEXT,
 created_at INTEGER NOT NULL, delivery_at INTEGER NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('pending','sending','sent','failed','deleted')),
 consent_version TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
 next_attempt INTEGER NOT NULL DEFAULT 0, lease_until INTEGER NOT NULL DEFAULT 0,
 draft_id TEXT, message_id TEXT, sent_at INTEGER, purged_at INTEGER,
 error_code TEXT, is_test INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS letters_due ON letters(status, delivery_at, next_attempt);
CREATE TABLE IF NOT EXISTS limits (id TEXT PRIMARY KEY, count INTEGER NOT NULL, expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS health (id INTEGER PRIMARY KEY CHECK(id=1), cron_at INTEGER, oauth_at INTEGER, oauth_ok INTEGER);
INSERT OR IGNORE INTO health(id) VALUES(1);
