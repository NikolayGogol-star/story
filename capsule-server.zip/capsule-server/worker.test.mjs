import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import worker,{cron,sendDue,OPEN_AT,DELIVERY_AT} from './worker.mjs';

function fixture(){
 const sqlite=new DatabaseSync(':memory:');sqlite.exec(readFileSync(new URL('./schema.sql',import.meta.url),'utf8'));
 let failSentUpdate=false;
 const DB={prepare(sql){let values=[];return {bind(...args){values=args;return this;},async first(){return sqlite.prepare(sql).get(...values)||null;},async all(){return {results:sqlite.prepare(sql).all(...values)};},async run(){if(failSentUpdate&&sql.includes("SET status='sent'")){failSentUpdate=false;throw Error('simulated D1 failure');}return sqlite.prepare(sql).run(...values);}};}};
 const env={DB,ADMIN_TOKEN:'a'.repeat(40),LETTER_KEY:Buffer.alloc(32,7).toString('base64'),RATE_SALT:'test-rate-salt',ALLOWED_ORIGIN:'https://nikolaygogol-star.github.io',TURNSTILE_HOSTNAME:'nikolaygogol-star.github.io',TURNSTILE_SECRET:'test-secret',GMAIL_SENDER:'sender@gmail.com',GOOGLE_CLIENT_ID:'test-client',GOOGLE_CLIENT_SECRET:'test-client-secret',GOOGLE_REFRESH_TOKEN:'test-refresh'};
 let sentCount=0,draftCount=0,transient=false;const drafts=new Map(),sent=new Map();
 const originalFetch=globalThis.fetch,originalNow=Date.now;let now=Date.parse('2026-10-26T12:00:00Z');Date.now=()=>now;
 globalThis.fetch=async(url,options={})=>{
  if(String(url).includes('siteverify'))return Response.json({success:true,hostname:env.TURNSTILE_HOSTNAME,action:'capsule'});
  if(String(url).includes('oauth2'))return Response.json({access_token:'fake-access'});
  const p=new URL(url).pathname;
  if(p.endsWith('/drafts')&&options.method==='POST'){const id='draft-'+(++draftCount);drafts.set(id,JSON.parse(options.body).message.raw);return Response.json({id});}
  if(p.endsWith('/drafts/send')){
   if(transient){transient=false;return Response.json({}, {status:503});}
   const {id}=JSON.parse(options.body);if(!drafts.has(id))return Response.json({}, {status:404});
   sentCount++;sent.set('message-'+sentCount,drafts.get(id));drafts.delete(id);return Response.json({id:'message-'+sentCount});
  }
  if(p.endsWith('/messages'))return Response.json({messages:[...sent.keys()].map(id=>({id}))});
  if(p.endsWith('/trash'))return Response.json({id:'trashed'});
  throw Error('Unexpected outgoing URL');
 };
 const payload={id:crypto.randomUUID(),token:Buffer.alloc(32,4).toString('base64url'),email:'reader@example.net',text:'Очень личное письмо\n\nСохрани эти слова <script> & ❤',consent:true,consentVersion:'2026-10-26',turnstileToken:'test-token'};
 const request=(path,data=payload,extra={})=>worker.fetch(new Request('https://capsule.example'+path,{method:'POST',headers:{Origin:env.ALLOWED_ORIGIN,'Content-Type':'application/json','CF-Connecting-IP':'192.0.2.1',...extra},body:JSON.stringify(data)}),env);
 return {env,sqlite,payload,request,setNow(n){now=n;},get sentCount(){return sentCount;},get sent(){return sent;},failNextSend(){transient=true;},failPersistence(){failSentUpdate=true;},close(){globalThis.fetch=originalFetch;Date.now=originalNow;sqlite.close();}};
}
test('consent, validation, CORS and admin authorization',async()=>{const f=fixture();try{
 assert.equal((await f.request('/letters',{...f.payload,consent:false})).status,400);
 assert.equal((await f.request('/letters',{...f.payload,email:'bad\r\nBcc: x'})).status,400);
 assert.equal((await f.request('/letters',f.payload,{Origin:'https://evil.example'})).status,403);
 assert.equal((await f.request('/admin/test')).status,401);
 assert.equal(f.sqlite.prepare('SELECT count(*) n FROM letters').get().n,0);
}finally{f.close();}});
test('encrypted durable save, duplicate submit, receipt, exact Moscow boundaries',async()=>{const f=fixture();try{
 assert.equal((await f.request('/letters')).status,201);
 assert.equal((await f.request('/letters')).status,200);
 const row=f.sqlite.prepare('SELECT * FROM letters').get();assert(!row.encrypted.includes('reader@'));assert(!row.encrypted.includes('личное'));
 assert.equal(f.sqlite.prepare('SELECT count(*) n FROM letters').get().n,1);
 f.setNow(OPEN_AT-1);assert.equal((await (await f.request('/receipt',{token:f.payload.token})).json()).chapter4Available,false);
 f.setNow(OPEN_AT);assert.equal((await (await f.request('/receipt',{token:f.payload.token})).json()).chapter4Available,true);
 assert.equal(new Date(DELIVERY_AT).toISOString(),'2027-10-28T07:00:00.000Z');assert.equal(new Date(OPEN_AT).toISOString(),'2026-10-27T21:00:00.000Z');
}finally{f.close();}});
test('no early email; due cron sends once under concurrent tasks and preserves exact text',async()=>{const f=fixture();try{
 await f.request('/letters');await cron(f.env,DELIVERY_AT-1);assert.equal(f.sentCount,0);
 await Promise.all([sendDue(f.env,DELIVERY_AT),sendDue(f.env,DELIVERY_AT)]);assert.equal(f.sentCount,1);
 await cron(f.env,DELIVERY_AT+3600000);assert.equal(f.sentCount,1);
 const raw=Buffer.from([...f.sent.values()][0],'base64url').toString();const body=Buffer.from(raw.split('\r\n\r\n')[1].replace(/\r\n/g,''),'base64').toString();assert(body.includes(f.payload.text));
 assert.equal(f.sqlite.prepare('SELECT status FROM letters').get().status,'sent');
 await cron(f.env,DELIVERY_AT+8*86400000);assert.equal(f.sqlite.prepare('SELECT encrypted FROM letters').get().encrypted,null);
}finally{f.close();}});
test('temporary error retries same draft; persistence failure reconciles without duplicate',async()=>{const f=fixture();try{
 await f.request('/letters');f.failNextSend();await sendDue(f.env,DELIVERY_AT);assert.equal(f.sentCount,0);assert.equal(f.sqlite.prepare('SELECT status FROM letters').get().status,'failed');
 f.failPersistence();await sendDue(f.env,DELIVERY_AT+86400000);assert.equal(f.sentCount,1);
 await sendDue(f.env,DELIVERY_AT+2*86400000);assert.equal(f.sentCount,1);assert.equal(f.sqlite.prepare('SELECT status FROM letters').get().status,'sent');
}finally{f.close();}});
test('receipt deletion wipes personal data and prevents sending',async()=>{const f=fixture();try{
 await f.request('/letters');assert.equal((await f.request('/delete',{token:'x'.repeat(43)})).status,404);
 assert.equal((await f.request('/delete',{token:f.payload.token})).status,200);
 assert.equal(f.sqlite.prepare('SELECT encrypted FROM letters').get().encrypted,null);
 await cron(f.env,DELIVERY_AT);assert.equal(f.sentCount,0);
}finally{f.close();}});
test('bot verification and rate limit reject automated submissions',async()=>{const f=fixture();try{
 globalThis.fetch=async()=>Response.json({success:false});assert.equal((await f.request('/letters')).status,403);
 for(let i=0;i<5;i++)await f.request('/letters');assert.equal((await f.request('/letters')).status,429);
 assert.equal(f.sqlite.prepare('SELECT count(*) n FROM letters').get().n,0);
}finally{f.close();}});
