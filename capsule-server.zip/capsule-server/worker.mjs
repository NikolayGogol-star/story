export const OPEN_AT = Date.parse('2026-10-28T00:00:00+03:00');
export const DELIVERY_AT = Date.parse('2027-10-28T10:00:00+03:00');
const DAY = 86400000;
const intro = 'Дорогая Аня!\n\nРовно год назад Вы доверили мне одно весьма ответственное поручение.\n\nПризнаться, хранить письмо целый год — занятие, требующее исключительного терпения. К счастью, терпение входит в число моих многочисленных достоинств.\n\nСегодня настало время вернуть Вам Ваши собственные слова.\n\nС днём рождения!';
const enc = new TextEncoder(), dec = new TextDecoder();
const b64 = bytes => {const a=new Uint8Array(bytes);let s='';for(let i=0;i<a.length;i+=8192)s+=String.fromCharCode(...a.subarray(i,i+8192));return btoa(s);};
const un64 = s => Uint8Array.from(atob(s), c=>c.charCodeAt(0));
const url64 = bytes => b64(bytes).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
const hash = async s => url64(await crypto.subtle.digest('SHA-256',enc.encode(s)));
const emailOK = s => typeof s==='string' && s.length<=254 && /^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?\.[A-Za-z]{2,}$/.test(s);
const headers = {'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'};
const json = (x,status=200,extra={}) => Response.json(x,{status,headers:{...headers,...extra}});
class Fault extends Error { constructor(code,status=400){super(code);this.code=code;this.status=status;} }
async function body(request) {
 const reader=request.body?.getReader(); if(!reader) throw new Fault('empty');
 let size=0, chunks=[];
 while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>130000){await reader.cancel();throw new Fault('too_long',413);}chunks.push(value);}
 const bytes=new Uint8Array(size);let offset=0;for(const c of chunks){bytes.set(c,offset);offset+=c.length;}
 try{return JSON.parse(dec.decode(bytes));}catch{throw new Fault('invalid_json');}
}
async function key(env){return crypto.subtle.importKey('raw',un64(env.LETTER_KEY),'AES-GCM',false,['encrypt','decrypt']);}
export async function encrypt(value,env){const iv=crypto.getRandomValues(new Uint8Array(12));const data=await crypto.subtle.encrypt({name:'AES-GCM',iv},await key(env),enc.encode(JSON.stringify(value)));return b64(iv)+'.'+b64(data);}
async function decrypt(s,env){const [iv,data]=s.split('.');return JSON.parse(dec.decode(await crypto.subtle.decrypt({name:'AES-GCM',iv:un64(iv)},await key(env),un64(data))));}
async function admin(request,env){const supplied=request.headers.get('Authorization')||'';if(!env.ADMIN_TOKEN||env.ADMIN_TOKEN.length<32)return false;const a=await hash(supplied),b=await hash('Bearer '+env.ADMIN_TOKEN);let x=0;for(let i=0;i<a.length;i++)x|=a.charCodeAt(i)^b.charCodeAt(i);return x===0;}
async function receipt(data,env){if(!/^[A-Za-z0-9_-]{43}$/.test(data.token||''))throw new Fault('not_found',404);const row=await env.DB.prepare('SELECT * FROM letters WHERE token_hash=?').bind(await hash(data.token)).first();if(!row)throw new Fault('not_found',404);return row;}
function state(row,now){return {saved:row.status!=='deleted',deleted:row.status==='deleted',status:row.status,deliveryAt:DELIVERY_AT,openAt:OPEN_AT,serverNow:now,chapter4Available:now>=OPEN_AT};}
async function limited(request,env,now){const bucket=Math.floor(now/3600000);const id=await hash(env.RATE_SALT+':'+(request.headers.get('CF-Connecting-IP')||'unknown')+':'+bucket);const row=await env.DB.prepare('INSERT INTO limits(id,count,expires) VALUES(?,1,?) ON CONFLICT(id) DO UPDATE SET count=count+1 RETURNING count').bind(id,now+2*3600000).first();if(row.count>5)throw new Fault('rate_limit',429);}
async function accessToken(env){
 const r=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({client_id:env.GOOGLE_CLIENT_ID,client_secret:env.GOOGLE_CLIENT_SECRET,refresh_token:env.GOOGLE_REFRESH_TOKEN,grant_type:'refresh_token'}),signal:AbortSignal.timeout(15000)});
 const d=await r.json();if(!r.ok||!d.access_token)throw new Fault('oauth_unavailable',503);return d.access_token;
}
async function gmail(token,path,method='GET',data){
 const r=await fetch('https://gmail.googleapis.com/gmail/v1/users/me/'+path,{method,headers:{Authorization:'Bearer '+token,...(data?{'Content-Type':'application/json'}:{})},body:data?JSON.stringify(data):undefined,signal:AbortSignal.timeout(20000)});
 if(!r.ok)throw new Fault('gmail_'+r.status,503);return r.status===204?{}:r.json();
}
function mime(row,value,env){
 const text=intro+'\n\n────────────────────\nВаше письмо себе\n────────────────────\n\n'+value.text+'\n\n────────────────────\nЭто письмо было написано 26–28 октября 2026 года в рамках истории «История, которой ещё нет».';
 const raw=['From: '+env.GMAIL_SENDER,'To: '+value.email,'Subject: =?UTF-8?B?'+b64(enc.encode('Письмо из прошлого.'))+'?=','Message-ID: <capsule-'+row.id+'@'+env.GMAIL_SENDER.split('@')[1]+'>','MIME-Version: 1.0','Content-Type: text/plain; charset=UTF-8','Content-Transfer-Encoding: base64','',''+b64(enc.encode(text)).match(/.{1,76}/g).join('\r\n')].join('\r\n');
 return url64(enc.encode(raw));
}
export async function sendDue(env,now=Date.now()){
 // Expired leases retain draft_id: retry sends the SAME draft, never a second email.
 const rows=(await env.DB.prepare("SELECT id FROM letters WHERE delivery_at<=? AND next_attempt<=? AND (status IN ('pending','failed') OR (status='sending' AND lease_until<?)) LIMIT 10").bind(now,now,now).all()).results;
 let token;
 for(const candidate of rows){
  const row=await env.DB.prepare("UPDATE letters SET status='sending',lease_until=?,attempts=attempts+1 WHERE id=? AND (status IN ('pending','failed') OR (status='sending' AND lease_until<?)) RETURNING *").bind(now+300000,candidate.id,now).first();
  if(!row)continue;
  try{
   token ||= await accessToken(env);
   if(!row.draft_id){
    const value=await decrypt(row.encrypted,env);
    const draft=await gmail(token,'drafts','POST',{message:{raw:mime(row,value,env)}});
    if(!draft.id)throw new Fault('draft_missing',503);
    try{await env.DB.prepare('UPDATE letters SET draft_id=? WHERE id=? AND status=\'sending\'').bind(draft.id,row.id).run();}
    catch(e){try{await gmail(token,'drafts/'+encodeURIComponent(draft.id),'DELETE');}catch{console.warn('capsule_orphan_draft_cleanup_pending',row.id);}throw e;}
    row.draft_id=draft.id;
   }
   let sent;
   try{sent=await gmail(token,'drafts/send','POST',{id:row.draft_id});}
   catch(e){
    if(e.code!=='gmail_404')throw e;
    // Gmail deletes a successfully sent draft. Reconcile by our stable Message-ID.
    const q='in:sent rfc822msgid:capsule-'+row.id+'@'+env.GMAIL_SENDER.split('@')[1];
    const found=await gmail(token,'messages?maxResults=1&q='+encodeURIComponent(q));
    if(!found.messages?.length)throw new Fault('draft_missing_needs_review',503);
    sent=found.messages[0];
   }
   if(!sent.id)throw new Fault('send_unconfirmed',503);
   await env.DB.prepare("UPDATE letters SET status='sent',message_id=?,sent_at=?,lease_until=0,error_code=NULL WHERE id=?").bind(sent.id,now,row.id).run();
  }catch(e){
   const code=/^(oauth_unavailable|gmail_\d+|draft_missing|draft_missing_needs_review|send_unconfirmed)$/.test(e.code||'')?e.code:'service_unavailable';
   await env.DB.prepare("UPDATE letters SET status='failed',error_code=?,next_attempt=?,lease_until=0 WHERE id=? AND status='sending'").bind(code,now+Math.min(DAY,300000*2**Math.min(row.attempts,8)),row.id).run();
   console.warn('capsule_delivery_failed',row.id,code); // Never log email, text, tokens or raw provider response.
  }
 }
}
export async function cron(env,now=Date.now()){
 await env.DB.prepare('UPDATE health SET cron_at=? WHERE id=1').bind(now).run();
 const h=await env.DB.prepare('SELECT * FROM health WHERE id=1').first();
 if(!h.oauth_at||now-h.oauth_at>7*DAY){
  try{await accessToken(env);await env.DB.prepare('UPDATE health SET oauth_at=?,oauth_ok=1 WHERE id=1').bind(now).run();}
  catch{await env.DB.prepare('UPDATE health SET oauth_ok=0 WHERE id=1').run();console.warn('capsule_oauth_check_failed');}
 }
 await sendDue(env,now);
 const old=(await env.DB.prepare("SELECT id,message_id FROM letters WHERE status='sent' AND sent_at<? AND purged_at IS NULL").bind(now-7*DAY).all()).results;
 for(const row of old){
  await env.DB.prepare('UPDATE letters SET encrypted=NULL WHERE id=?').bind(row.id).run();
  try{const t=await accessToken(env);await gmail(t,'messages/'+encodeURIComponent(row.message_id)+'/trash','POST');await env.DB.prepare('UPDATE letters SET purged_at=? WHERE id=?').bind(now,row.id).run();}catch{console.warn('capsule_mailbox_cleanup_pending',row.id);}
 }
 const deleted=(await env.DB.prepare("SELECT id,draft_id FROM letters WHERE status='deleted' AND purged_at IS NULL").all()).results;
 for(const row of deleted){
  try{
   if(row.draft_id){const t=await accessToken(env);try{await gmail(t,'drafts/'+encodeURIComponent(row.draft_id),'DELETE');}catch(e){if(e.code!=='gmail_404')throw e;}}
   await env.DB.prepare('UPDATE letters SET purged_at=? WHERE id=?').bind(now,row.id).run();
  }catch{console.warn('capsule_deleted_draft_cleanup_pending',row.id);}
 }
 await env.DB.prepare('DELETE FROM limits WHERE expires<?').bind(now).run();
}
export default {
 async fetch(request,env){
  const url=new URL(request.url),origin=request.headers.get('Origin'),cors=origin===env.ALLOWED_ORIGIN?{'Access-Control-Allow-Origin':origin,Vary:'Origin'}:{};
  try{
   if(url.pathname.startsWith('/admin/')){
    if(!await admin(request,env))return json({allowed:false},401);
    if(url.pathname==='/admin/status'&&request.method==='GET'){
     const health=await env.DB.prepare('SELECT * FROM health WHERE id=1').first();
     const letters=(await env.DB.prepare('SELECT id,status,created_at,delivery_at,attempts,next_attempt,sent_at,purged_at,error_code,is_test FROM letters').all()).results;
     return json({health,letters,openAt:OPEN_AT,deliveryAt:DELIVERY_AT,now:Date.now()});
    }
    if(url.pathname==='/admin/test'&&request.method==='POST'){
     const d=await body(request);if(!emailOK(d.email)||typeof d.text!=='string'||d.text.length>30000)throw new Fault('invalid');
     const id=crypto.randomUUID(),now=Date.now();
     await env.DB.prepare("INSERT INTO letters(id,token_hash,encrypted,created_at,delivery_at,status,consent_version,is_test) VALUES(?,?,?,?,?,'pending','admin-test',1)").bind(id,await hash(crypto.randomUUID()),await encrypt({email:d.email,text:d.text},env),now,now).run();
     // Real recipient and synthetic text entered manually by organizer; no birthday letter is modified.
     await sendDue(env,now);return json({id});
    }
    return json({found:false},404);
   }
   if(origin!==env.ALLOWED_ORIGIN)return json({allowed:false},403);
   if(request.method==='OPTIONS')return new Response(null,{status:204,headers:{...headers,...cors,'Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'Content-Type'}});
   if(url.pathname==='/clock'&&request.method==='GET')return json({serverNow:Date.now(),openAt:OPEN_AT,deliveryAt:DELIVERY_AT},200,cors);
   if(request.method!=='POST')return json({found:false},404,cors);
   const data=await body(request),now=Date.now();
   if(url.pathname==='/receipt')return json(state(await receipt(data,env),now),200,cors);
   if(url.pathname==='/delete'){
    const row=await receipt(data,env);
    const changed=await env.DB.prepare("UPDATE letters SET status='deleted',encrypted=NULL WHERE id=? AND status IN ('pending','failed') RETURNING id").bind(row.id).first();
    if(!changed&&row.status!=='deleted')throw new Fault('already_sending',409);
    return json({...state({...row,status:'deleted'},now)},200,cors);
   }
   if(url.pathname!=='/letters')return json({found:false},404,cors);
   if(!/^[A-Za-z0-9_-]{43}$/.test(data.token||'')||!/^[0-9a-f-]{36}$/.test(data.id||''))throw new Fault('invalid');
   const tokenHash=await hash(data.token);
   const existing=await env.DB.prepare('SELECT * FROM letters WHERE token_hash=?').bind(tokenHash).first();
   if(existing)return json(state(existing,now),200,cors); // Lost response can be retried without another letter.
   await limited(request,env,now);
   if(data.consent!==true||data.consentVersion!=='2026-10-26')throw new Fault('consent_required');
   if(!emailOK(data.email)||typeof data.text!=='string'||!data.text.trim()||data.text.length>30000)throw new Fault('invalid_fields');
   if(!env.TURNSTILE_SECRET||!env.LETTER_KEY||!emailOK(env.GMAIL_SENDER)||!env.GOOGLE_CLIENT_ID||!env.GOOGLE_CLIENT_SECRET||!env.GOOGLE_REFRESH_TOKEN||!env.RATE_SALT||!env.ADMIN_TOKEN||env.ADMIN_TOKEN.length<32)throw new Fault('not_configured',503);
   const check=await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({secret:env.TURNSTILE_SECRET,response:data.turnstileToken,remoteip:request.headers.get('CF-Connecting-IP')}),signal:AbortSignal.timeout(10000)});
   const verdict=await check.json();if(!verdict.success||verdict.hostname!==env.TURNSTILE_HOSTNAME||verdict.action!=='capsule')throw new Fault('verification_required',403);
   const encrypted=await encrypt({email:data.email,text:data.text},env);
   await env.DB.prepare("INSERT OR IGNORE INTO letters(id,token_hash,encrypted,created_at,delivery_at,status,consent_version) VALUES(?,?,?,?,?,'pending',?)").bind(data.id,tokenHash,encrypted,now,DELIVERY_AT,data.consentVersion).run();
   return json(state(await receipt(data,env),now),201,cors);
  }catch(e){return json({code:e instanceof Fault?e.code:'service_unavailable'},e instanceof Fault?e.status:503,cors);}
 },
 async scheduled(event,env,ctx){ctx.waitUntil(cron(env));}
};
