"""Manual organizer console. Credentials are prompted, never embedded in a URL or file."""
import argparse
import getpass
import json
from urllib.request import Request, urlopen
from urllib.error import HTTPError

parser = argparse.ArgumentParser()
parser.add_argument('command', choices=['status', 'test'])
args = parser.parse_args()
base = input('HTTPS-адрес Worker: ').strip().rstrip('/')
if not base.startswith('https://'):
    raise SystemExit('Нужен HTTPS-адрес опубликованного Worker.')
token = getpass.getpass('ADMIN_TOKEN (ввод скрыт): ')
data = None
path = '/admin/status'
if args.command == 'test':
    print('Будет отправлено настоящее тестовое письмо. Не вводите личные переживания или письмо Ани.')
    email = input('Ваш собственный email для теста: ').strip()
    text = input('Короткий тестовый текст: ')
    if input('Отправить тестовое письмо на этот адрес? Напишите ДА: ') != 'ДА':
        raise SystemExit('Отменено.')
    data = json.dumps({'email': email, 'text': text}).encode()
    path = '/admin/test'
request = Request(base + path, data=data, headers={'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json', 'Accept': 'application/json', 'User-Agent': 'AnnaFutureLetterAdmin/1.0 (+https://nikolaygogol-star.github.io/story/)'})
try:
    with urlopen(request, timeout=60) as response:
        print(json.dumps(json.load(response), ensure_ascii=False, indent=2))
except HTTPError as error:
    print('Сервис вернул статус', error.code, '— проверьте настройку; секреты не выводятся.')
except (json.JSONDecodeError, UnicodeDecodeError):
    print('Сервер ответил не в формате капсулы. Нужно проверить, что опубликован наш Worker, а не Hello World.')
